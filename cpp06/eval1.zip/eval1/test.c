#include <stdio.h>

int main() {
	int a = 1;
	printf("%p\n", (void *)a);
}
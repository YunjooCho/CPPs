/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   main.cpp                                           :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: yunjcho <yunjcho@student.42seoul.kr>       +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2023/09/24 17:37:52 by yunjcho           #+#    #+#             */
/*   Updated: 2023/10/17 18:21:23 by yunjcho          ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "Data.hpp"
#include "Serializer.hpp"
#include "iostream"

int	main(void)
{
	// Data		data;
	// uintptr_t	serialVal;
	// Data		*deserialVal;
	
	// data.val = -10;
	// serialVal = Serializer::serialize(&data);
	// deserialVal = Serializer::deserialize(serialVal);

	// std::cout << "Input value is : " << data.val << std::endl;
	// std::cout << "deserialVal's value : " << deserialVal->val << std::endl;
	// if (deserialVal == &data)
	// {
	// 	std::cout << "SUCCESS !" << std::endl;
	// }
	// else
	// {
	// 	std::cout << "FAILURE !" << std::endl;
	// }

	// return (0);
	std::cout << Serializer::serialize(NULL) << std::endl;
	std::cout << Serializer::deserialize(0) << std::endl;
}
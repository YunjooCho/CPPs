#include <iostream>

class A {};

class B: public A {};

class C {};

int main() {
	int i = 1;
	int* pi = &i;

	float* pf = reinterpret_cast<float*>(pi);
}